# Anti-Patterns: Words, Phrases, and Structures to Eliminate

This file is a checklist. Before publishing any KeyVendors AC rental content, scan the draft against every entry below. If you find a match, use the replacement column. No exceptions.

---

## 1) Banned Words

These words never appear in KeyVendors AC rental copy.

| Banned Word | Why | Replace With |
|---|---|---|
| Luxury | Wrong positioning. KeyVendors is budget-to-mid, not luxury. | "Quality" or just state the spec |
| Premium | Same as luxury. Competitor vocabulary. | "Well-maintained" or name the AC brand/tonnage |
| Bespoke | AI/luxury tell. No renter in Delhi uses this word. | "Custom" or "flexible" |
| World-class | Unsubstantiated superlative. | "Rated 4.8/5 by 1,200+ customers" |
| Best-in-class | Same problem. | Specific proof: "serving Delhi NCR since 2016" |
| Pinnacle | Pure filler. | Delete the sentence. Rewrite with a fact. |
| Plethora | AI tell. Formal. No one speaks like this. | "Many" or use the actual number |
| Myriad | Same as plethora. | A number or "several" |
| Cheap / Cheapest | Devalues the service. Makes the reader question quality. | "Budget-friendly" or lead with the actual price: "from Rs 999/month" |
| Elegance | Luxury vocabulary. Wrong audience entirely. | Delete. AC rental does not need elegance. |
| Sophistication | Same. | Delete or replace with a functional benefit. |
| Opulence | Same. | Delete. |
| Artisan | Luxury positioning word. | "Experienced technician" or "verified technician" |
| Craftsmanship | Same. | "Skilled team" or "trained professionals" |
| Exquisite | Same. | Delete. |
| Unparalleled | Unsubstantiated. | A specific stat or proof point. |
| Curated | Overused, sounds like a fashion brand. | "Vetted" or "verified" |
| Elevate | Aspirational filler. | State the functional benefit. |
| Empower | Corporate filler. | State what the customer can actually do. |

---

## 2) Banned Phrases

| Banned Phrase | Why | Replace With |
|---|---|---|
| "In today's world" | Generic AI opener. | Start with the customer's problem or the price. |
| "In the scorching Delhi heat" | Cliche. Every AC rental page in India uses this. | "Delhi summers cross 45 degrees C. You need an AC that works — and a rental plan that fits your budget." |
| "Beat the heat" | Overused to the point of meaninglessness. | Name the specific outcome: "Cool your room for Rs 999/month." |
| "Transform your space" | Aspirational filler. Wrong brand voice. | "Get a working AC installed in your room by tomorrow." |
| "Seamless experience" | Vague. What is seamless? | Describe the actual process: "We deliver, install, and maintain. You do nothing." |
| "Holistic solution" | Corporate jargon. | Name the specific inclusions: "Rental covers delivery, installation, and maintenance." |
| "Comprehensive service" | Same. Vague. | "Free delivery. Free installation. Free maintenance. One monthly payment." |
| "State-of-the-art" | No renter cares about this phrase. | Name the AC spec: "1.5 Ton Split AC, energy efficient." |
| "One-stop solution" | Overused. | "Everything included: delivery (Rs 199), installation (free for Window AC), maintenance (free)." |
| "Cutting-edge technology" | Irrelevant for rental ACs. | Delete. Talk about cooling capacity or tonnage instead. |
| "Game-changer" | Hype word. AC rental is not a game-changer. It is a practical decision. | Delete. |
| "Hassle-free" | Overused. Every competitor says this. | Describe what specifically is hassle-free: "We handle installation. You do not need to arrange a technician." |
| "At your doorstep" | Cliche. | "Delivered to your address in Delhi NCR for Rs 199." |
| "Look no further" | Pushy and generic. | Delete. Let the pricing and proof do the convincing. |
| "Your comfort is our priority" | Empty corporate promise. | "Free maintenance means if your AC stops working, we fix it at no extra cost." |
| "We take pride in" | Self-congratulatory. The reader does not care about your pride. | State the fact: "1,200+ customers since 2016." |
| "Trust us" / "You can trust" | Telling someone to trust you undermines trust. | Show trust signals: rating, customer count, refundable deposit, years in business. |
| "Don't miss out" | False urgency. | If there is real urgency (summer season), state it factually: "Summer bookings fill up by April. Book now to lock your delivery date." |
| "Limited time offer" | Only use if the offer genuinely expires. Never fabricate scarcity. | State the actual deadline if one exists. Otherwise delete. |

---

## 3) Structural Anti-Patterns

### 3a) The "Why Choose Us" Dump

**Problem**: Clustering all trust signals into one "Why Choose KeyVendors?" section that reads like a brochure. The reader may never scroll that far.

**Fix**: Distribute trust signals across the page.
- Mention "since 2016" in the hero section.
- Drop "4.8/5 rating" next to the pricing table.
- Weave "1,200+ customers" into an FAQ answer.
- Place "refundable deposit" near the pricing section where deposit anxiety peaks.

### 3b) Feature-First Writing

**Problem**: Leading with what KeyVendors offers instead of what the customer needs.

| Wrong | Right |
|---|---|
| "KeyVendors provides Window AC rental with free installation and maintenance." | "Need an AC for your PG room this summer? Window AC on rent from Rs 999/month. Free installation. Free maintenance." |
| "Our team of verified technicians ensures quality service." | "Every AC is installed by a verified technician. If anything breaks, we send someone to fix it — no extra charge." |

### 3c) Vague Pricing

**Problem**: Using phrases like "affordable rates", "competitive pricing", or "budget-friendly plans" without actual numbers.

**Fix**: Always state the rupee figure.
- Wrong: "We offer affordable AC rental plans for every budget."
- Right: "Window AC: Rs 999/month. Split AC: Rs 2,399/month. Security deposit refundable when you return the unit."

### 3d) Generic Location References

**Problem**: Writing "we serve Delhi" without locality-level specificity. Every competitor says "Delhi NCR."

**Fix**: Name actual areas.
- Wrong: "We provide AC on rent across Delhi NCR."
- Right: "AC on rent in Laxmi Nagar, Dwarka, Rohini, Noida Sector 62, and 100+ other localities across Delhi NCR."

### 3e) Wall-of-Text Descriptions

**Problem**: Long paragraphs explaining the rental process when a numbered list or table would be clearer.

**Fix**: Use the format that matches the content type.
- Process steps: numbered list (3-4 steps, one sentence each)
- Plan comparison: table with columns for AC type, price, duration, deposit
- Inclusions: bullet list with checkmarks
- FAQs: question as H3, answer as 2-3 sentences max

### 3f) Ignoring Budget Anxiety

**Problem**: Mentioning the deposit amount without immediately clarifying it is refundable. Listing prices without explaining what is included. Leaving the reader wondering about hidden charges.

**Fix**: Every price mention includes what is covered. Every deposit mention says "refundable." Every section that could trigger cost worry should immediately resolve it.

- Wrong: "Security deposit: Rs 3,000 to Rs 5,999."
- Right: "Security deposit: Rs 3,000 to Rs 5,999 (fully refundable when you return the AC in working condition)."

### 3g) The Swap Test Failure

**Problem**: Writing sentences so generic they work for any home service. If you can replace "AC rental" with "plumber" or "electrician" and the sentence still makes sense, it is too vague.

**Test every sentence**:
- "We provide reliable [AC rental / plumbing] services across Delhi NCR" — FAILS. Too generic.
- "1.5 Ton Split AC on rent at Rs 2,399/month with free maintenance for 7 months" — PASSES. This only works for AC rental.

### 3h) CTA Mismatch

**Problem**: Using "Book a Free Consultation" (interior design CTA) for AC rental. Or using a form CTA when the reader is in urgent mode and needs a phone number.

**Fix**: Match CTA to intent.
- Urgent intent: "Call 9018181818 now" or "WhatsApp 8700359955"
- Planned intent: "View all AC rental plans" or "Check prices for your area"
- Never use: "Book a Free Consultation" (wrong service), "Get a Quote" (prices are already fixed and public)

---

## 4) Tone Anti-Patterns

### 4a) Over-Enthusiasm

- Wrong: "We are SO excited to bring you the BEST AC rental experience in Delhi!!!"
- Right: "AC on rent in Delhi. Window AC from Rs 999/month. Split AC from Rs 2,399/month. Free installation. Free maintenance."

### 4b) Condescension

- Wrong: "We understand that not everyone can afford to buy an AC."
- Right: "Renting an AC costs less than buying one and you get free maintenance included."

### 4c) Fear-Based Selling

- Wrong: "Don't suffer through another Delhi summer without an AC!"
- Right: "Delhi summers last 5 months. A Window AC rental for the full season costs Rs 7,999 — that is Rs 1,600/month."

### 4d) Competitor Bashing

- Wrong: "Unlike other rental companies that charge hidden fees..."
- Right: "KeyVendors pricing: Rs 999/month + Rs 199 delivery + refundable deposit. No hidden charges. No surprise bills."

State your own terms clearly. The reader will draw their own conclusions about competitors.

---

## 5) SEO Anti-Patterns

### 5a) Keyword Stuffing

- Wrong: "AC on rent in Delhi is the best AC on rent option. If you need AC on rent in Delhi, our AC on rent service in Delhi covers all of Delhi."
- Right: Use the primary keyword in H1, first paragraph, one H2, and meta title. Use natural variations elsewhere: "rent an AC", "AC rental plans", "monthly AC rental."

### 5b) Thin FAQ Answers

- Wrong: "Yes, we provide AC on rent in Noida." (7 words, no value)
- Right: "Yes. KeyVendors delivers AC on rent across Noida — including Sector 62, Sector 18, and Greater Noida. Delivery costs Rs 199. Call 9018181818 to book." (specific, useful, has a CTA)

### 5c) Missing Internal Links

Every AC rental page must link to:
- 2-3 city/area pages (AC on rent in Noida, AC on rent in Gurgaon)
- 2-3 related service pages (AC service in Delhi, AC installation in Delhi)
- 2-3 relevant blog posts (AC buying vs renting guide, AC maintenance tips)

Use descriptive anchor text. Never "click here." Never naked URLs.
