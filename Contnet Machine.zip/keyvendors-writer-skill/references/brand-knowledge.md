# KeyVendors AC Rental — Brand Knowledge Base

This file is the single source of truth for all AC rental content. Every price, plan name, service area, and contact detail in published content must match this document. Do not invent figures. Do not round prices. If a detail is missing here, ask before publishing.

Last updated: 2026-03-30

---

## 1) Company Overview

| Attribute | Detail |
|---|---|
| Company name | KeyVendors |
| Founded | 2016 |
| Business model | Home services marketplace — connects customers with vetted professionals |
| Positioning | Budget-to-mid-range. Transparent pricing. Not luxury, not cheapest. |
| Network size | 50+ vetted professionals |
| Customer count | 1,200+ customers served |
| Average rating | 4.8 out of 5 |
| Primary geography | Delhi NCR |
| Website | https://www.keyvendors.com |
| AC rental page | https://www.keyvendors.com/services/ac-on-rent-delhi |
| Phone | 9018181818 |
| WhatsApp | 8700359955 |

### What KeyVendors IS

- A verified home services marketplace with transparent pricing
- Budget-to-mid positioning: honest about what you get at each price point
- End-to-end for AC rental: delivery, installation, maintenance, pickup — one entity handles everything
- Focused on Delhi NCR with locality-level coverage

### What KeyVendors is NOT

- Not a luxury appliance rental brand (like Rentomojo's premium tier)
- Not an individual technician or local AC mechanic
- Not a tech startup selling software — it sells physical AC rental and service
- Not a national brand — focused on Delhi NCR specifically

---

## 2) AC Rental Plans and Pricing

### Monthly Plans

| Plan | AC Type | Tonnage | Duration | Monthly Price | Security Deposit | Installation | Maintenance |
|---|---|---|---|---|---|---|---|
| Window AC Monthly | Window | 1.0 Ton | 10 months | Rs 999/month | Rs 3,000 (refundable) | Free | Free |
| Window AC 1.5 Ton Monthly | Window | 1.5 Ton | 7 months | Rs 1,988/month | Rs 3,000-Rs 4,000 (refundable) | Free | Free |
| Split AC 1.5 Ton Monthly | Split | 1.5 Ton | 7 months | Rs 2,399/month | Rs 5,000-Rs 5,999 (refundable) | Rs 1,899 | Free |

### Full Season Plans

| Plan | AC Type | Tonnage | Season Price | Security Deposit | Installation | Maintenance |
|---|---|---|---|---|---|---|
| Window AC Full Season | Window | 1.0 Ton | Rs 7,999 | Rs 3,000 (refundable) | Free | Free |
| Split AC Full Season | Split | 1.5 Ton | Rs 11,999 | Rs 5,000-Rs 5,999 (refundable) | Rs 1,899 | Free |

### Pricing Notes

- **Security deposit**: Rs 3,000 to Rs 5,999 depending on AC type. Fully refundable when the AC is returned in working condition.
- **Delivery charge**: Rs 199 flat across Delhi NCR.
- **Installation (Window AC)**: Free. No additional charge.
- **Installation (Split AC)**: Rs 1,899. Covers copper piping, bracket, and labour.
- **Maintenance**: Free for the entire rental period. If the AC develops a fault, KeyVendors sends a technician at no cost.
- **No hidden charges**: The monthly price, delivery fee, and installation fee (if applicable) are the only costs. No service charges, no seasonal surcharges.

### Plan Comparison (for content use)

| Factor | Window AC (1 Ton) | Split AC (1.5 Ton) |
|---|---|---|
| Monthly price | Rs 999 | Rs 2,399 |
| Full season price | Rs 7,999 | Rs 11,999 |
| Cooling capacity | Suitable for rooms up to 120 sqft | Suitable for rooms up to 180 sqft |
| Installation | Free (window-mounted) | Rs 1,899 (wall-mounted, needs copper piping) |
| Noise level | Moderate (compressor inside room) | Low (compressor outside) |
| Best for | PG rooms, small bedrooms, single-room tenants | Living rooms, master bedrooms, offices |
| Requires window space | Yes | No |
| Security deposit | Rs 3,000 | Rs 5,000-Rs 5,999 |

---

## 3) Service Inclusions

Every AC rental from KeyVendors includes:

- **Delivery**: AC unit delivered to the customer's address. Rs 199 delivery charge.
- **Installation**: Free for Window AC. Rs 1,899 for Split AC (includes copper piping, bracket, and labour).
- **Maintenance**: Free for the full rental period. Covers any mechanical or gas-related faults.
- **Technician visits**: Verified technicians handle installation, maintenance, and pickup.
- **Pickup**: At the end of the rental period, KeyVendors picks up the AC unit. No charge for pickup.
- **Refundable deposit**: Deposit returned when the AC is returned in working condition.

### What is NOT Included

- Electrical wiring or stabilizer (customer's responsibility)
- Damage caused by misuse or negligence (deducted from deposit)
- Shifting the AC to a new address mid-rental (contact KeyVendors for relocation; may involve a reinstallation charge)

---

## 4) How AC Rental Works (Process)

**Step 1: Choose Your Plan**
Browse Window AC and Split AC plans on the website or call 9018181818. Pick monthly or full-season.

**Step 2: Book and Pay Deposit**
Pay the refundable security deposit (Rs 3,000 to Rs 5,999) and the first month's rent or full season amount. Delivery fee of Rs 199 applies.

**Step 3: Delivery and Installation**
A verified technician delivers and installs the AC at your address. Window AC installation is free. Split AC installation costs Rs 1,899.

**Step 4: Use and Maintain**
Use the AC for the rental period. If anything goes wrong, call KeyVendors. Maintenance is free — a technician visits and fixes the issue at no cost.

**Step 5: Return or Extend**
At the end of your rental period, return the AC and get your deposit back. Want to continue? Extend the rental.

---

## 5) Target Audience (AC Rental Specific)

### ICP A: Student / PG Tenant (High Volume, Low Ticket)

| Attribute | Detail |
|---|---|
| Age | 18-28 years |
| Living situation | PG accommodation, shared flat, hostel, or rented single room |
| Location | Laxmi Nagar, Mukherjee Nagar, Kalu Sarai, GTB Nagar, Noida Sector 62, Dwarka |
| Room size | 80-120 sqft |
| Budget | Lowest possible. Price is the deciding factor. |
| Typical plan | Window AC Monthly at Rs 999/month |
| Key concerns | "Is the deposit really refundable?" "What if the AC breaks?" "Can I return it early?" |
| Decision speed | Fast. Needs AC within 1-2 days of searching. |
| Search queries | "ac on rent in delhi", "cheap ac on rent near me", "window ac on rent monthly", "ac rent price delhi" |
| CTA preference | WhatsApp (8700359955) or phone call (9018181818) |

### ICP B: Tenant / Young Professional (Mid Volume, Mid Ticket)

| Attribute | Detail |
|---|---|
| Age | 25-38 years |
| Living situation | Rented 1 BHK or 2 BHK flat. May need 1-2 ACs. |
| Location | Dwarka, Rohini, Indirapuram, Vaishali, Noida, Gurgaon Sector 49-56 |
| Room size | 120-180 sqft per room |
| Budget | Willing to pay more for comfort. Considers Split AC. |
| Typical plan | Split AC Monthly at Rs 2,399/month or Window AC 1.5 Ton at Rs 1,988/month |
| Key concerns | "Is the AC well-maintained?" "How quickly can you install a Split AC?" "What brands do you provide?" |
| Decision speed | 3-7 days. Compares 2-3 providers. |
| Search queries | "split ac on rent in delhi", "1.5 ton ac on rent", "ac on rent in noida", "ac on rent in gurgaon" |
| CTA preference | Website booking or WhatsApp |

### ICP C: Small Office / Shop Owner (Low Volume, Higher Ticket)

| Attribute | Detail |
|---|---|
| Age | 30-50 years |
| Situation | Rented office, co-working space, shop, salon, clinic |
| Location | Nehru Place, Connaught Place, Lajpat Nagar, Kirti Nagar, Noida commercial sectors |
| Cooling need | 1-4 Split ACs for 500-1,500 sqft |
| Budget | Business expense. Values reliability over lowest price. |
| Typical plan | Multiple Split AC Full Season at Rs 11,999 each |
| Key concerns | "Can you install multiple ACs in one visit?" "Do you handle commercial properties?" "What is the timeline for installation?" |
| Decision speed | 1-2 weeks. May need landlord approval. |
| Search queries | "ac on rent for office in delhi", "commercial ac rental delhi", "bulk ac rental" |
| CTA preference | Phone call (9018181818) |

---

## 6) Geographic Coverage

### Primary Cities

| City | Status | Key Localities |
|---|---|---|
| Delhi | Full coverage | Dwarka, Rohini, Laxmi Nagar, Shahdara, Pitampura, Janakpuri, Karol Bagh, South Delhi (Saket, GK, Malviya Nagar), West Delhi, East Delhi, North Delhi |
| Noida | Full coverage | Sector 18, Sector 62, Sector 63, Sector 137, Sector 143, Greater Noida, Noida Extension |
| Gurgaon | Full coverage | Sector 49, Sector 56, Sector 82, DLF Phase 1-5, Sohna Road, Golf Course Road, Manesar |
| Ghaziabad | Full coverage | Indirapuram, Vaishali, Vasundhara, Raj Nagar Extension, Crossing Republik |
| Greater Noida | Full coverage | Alpha, Beta, Gamma, Chi, Zeta, Pari Chowk, Knowledge Park |
| Faridabad | Full coverage | Sector 15, Sector 21, NIT, Ballabgarh, SRS Residency |

### Locality Groups for Content Targeting

**Student hubs**: Laxmi Nagar, Mukherjee Nagar, Kalu Sarai, GTB Nagar, Karol Bagh, Noida Sector 62
**Tenant-heavy areas**: Dwarka, Rohini, Indirapuram, Vaishali, Noida Sector 18, Gurgaon Sector 49-56
**Commercial zones**: Nehru Place, Connaught Place, Lajpat Nagar, Kirti Nagar, Noida Sector 63
**New developments**: Noida Extension, Greater Noida, Raj Nagar Extension, Crossing Republik, Sohna Road

---

## 7) Verified Technicians

KeyVendors uses a network of 50+ verified professionals for AC rental delivery, installation, and maintenance across Delhi NCR.

### Technician Standards

| Standard | Detail |
|---|---|
| Verification | ID verified, background checked, skill-tested before onboarding |
| Experience | Minimum 2 years of AC installation and repair experience |
| Equipment | Technicians carry their own tools. No extra charge for equipment. |
| Uniform | KeyVendors-branded uniform for identification |
| Coverage | Technicians assigned by locality zone. Reduces travel time, faster service. |
| Accountability | All work tracked through KeyVendors system. Customer can rate the technician. |

### Service Capabilities

- Window AC installation (wall-mount, window-mount)
- Split AC installation (indoor unit mount, outdoor unit mount, copper piping, bracket fitting)
- Gas refilling and leak detection
- Compressor and fan motor diagnostics
- PCB and electrical fault diagnosis
- Routine cleaning and filter maintenance
- AC uninstallation and pickup at end of rental

---

## 8) Trust Signals (Use These in Content)

Distribute these across content. Do not cluster them.

| Signal | Where to Use |
|---|---|
| Since 2016 | Hero section, About paragraph, FAQ answers |
| 1,200+ customers | Near pricing table, in testimonial context, hero trust bar |
| 4.8/5 rating | Trust bar, near CTA buttons, FAQ about reliability |
| Refundable deposit | Every pricing section, FAQ about deposits, near checkout/booking CTA |
| Free maintenance | Pricing table, What You Get bullets, FAQ about breakdowns |
| Free installation (Window AC) | Pricing comparison, hero bullets, FAQ about installation |
| 50+ verified technicians | Service quality section, FAQ about technician reliability |
| Rs 199 delivery | Pricing transparency section, FAQ about hidden charges |

---

## 9) Competitive Context (for Positioning, Not for Bashing)

KeyVendors competes with:

| Competitor Type | Examples | KeyVendors Differentiator |
|---|---|---|
| National rental platforms | Rentomojo, RentoMojo, Cityfurnish | KeyVendors is Delhi NCR focused. Local technicians. Faster response. Lower deposits for Window AC. |
| Local AC rental shops | Neighbourhood AC mechanics, Justdial listings | KeyVendors has verified technicians, free maintenance, refundable deposit with a system. Local shops often lack guarantees. |
| OEM rental programs | Blue Star, Voltas rental schemes | KeyVendors offers lower entry prices. Window AC from Rs 999/month is below most OEM rental minimums. |

**Positioning statement for content**: KeyVendors is the Delhi NCR AC rental service with transparent pricing, free maintenance, and verified technicians — from Rs 999/month for a Window AC.

---

## 10) Seasonal Context

### Delhi NCR AC Rental Calendar

| Month | Context | Content Angle |
|---|---|---|
| February-March | Early birds start booking. Stock is full. | "Book early for guaranteed delivery. Summer bookings start filling up in March." |
| April | Peak demand starts. Temperatures cross 38 degrees C. | Urgent voice. Same-day delivery angle. Phone CTA. |
| May-June | Peak summer. 42-46 degrees C. Highest demand. | Urgent voice. Stock scarcity may be real — state it factually if true. |
| July-August | Monsoon. Demand drops. Some returns start. | Planned voice. "Extend your rental through monsoon at the same monthly rate." |
| September | Season winding down. Returns begin. | "Return your AC before October. Deposit refunded within X days." |
| October-November | Off-season. Minimal demand. | Maintenance content. "AC maintenance tips before storage." Blog content only. |

### Temperature-Based Urgency (for Ad Copy)

- Below 35 degrees C: Planned voice. Comparison content. Price tables.
- 35-40 degrees C: Mixed. Urgency building. "Book now before peak demand."
- Above 40 degrees C: Full urgent voice. "Call 9018181818. Get AC delivered today."

---

## 11) Content Reuse Rules

### Prices

Always pull from Section 2 of this document. If a price has changed, update this document first, then update all content.

### Trust Signals

Use the exact figures from Section 8. Do not round "1,200+" to "thousands" or "4.8/5" to "high rating."

### Contact Details

- Phone: 9018181818 (for calls)
- WhatsApp: 8700359955 (for chat)
- Never publish personal phone numbers of technicians or staff.
- Never fabricate a "toll-free" number unless one exists.

### Service Areas

Use locality names from Section 6. Do not invent locality coverage. If unsure whether KeyVendors serves a specific locality, confirm before publishing.
