# Heading Kill List

## Purpose

These heading patterns must never appear in KeyVendors AC rental content. Every heading on this list fails one or more of these tests:

1. **Generic** - Could appear on any AC rental website without changes
2. **Keyword-empty** - Contains no target keyword or search intent signal
3. **Punctuation violation** - Contains em dashes, colons, or banned formatting
4. **Question filler** - Asks a question the reader already knows the answer to
5. **AI pattern** - Follows a template that AI models default to

When you find a heading from this list (or matching its pattern), flag it and provide a specific replacement that includes a keyword, price, locality, or concrete detail.

---

## Category 1: Generic Headings (Fails the "Any AC Rental Company" Test)

These headings could appear on Rentomojo, CityFurnish, Furlenco, or any other competitor page with zero changes. They carry no KeyVendors-specific information.

| Kill | Why | Example Replacement |
|---|---|---|
| Our Services | Says nothing, no keyword | "Window AC and Split AC on Rent in Delhi NCR" |
| Why Choose Us | Generic trust section header | "Why 1,200+ Customers Rent AC from KeyVendors" |
| About Us | Not relevant for a service page | "KeyVendors: AC Rental in Delhi Since 2016" |
| About AC Rental | No specificity, no keyword | "How AC on Rent Works: Delivery to Pickup in 4 Steps" |
| Our Mission | Corporate filler, no one reads this | Delete the section entirely |
| Our Vision | Same as above | Delete the section entirely |
| What We Offer | Generic, no keyword | "AC Rental Plans: Window AC from Rs.999, Split AC from Rs.2,399" |
| Our Commitment | Vague, no proof | "Free Maintenance and 48-Hour Replacement Guarantee" |
| Welcome to KeyVendors | Wastes H1/H2 space | Use the primary keyword instead |
| Introduction | No reader cares about a heading called "Introduction" | Delete or merge content into the section above |
| Overview | Same as above | Delete or rewrite with keyword |
| AC Rental Services | Too generic, missing location | "AC on Rent in Delhi: Monthly Plans with Free Installation" |
| Our Products | Wrong framing (it is a rental, not a product) | "Window AC and Split AC Available for Rent" |
| Contact Us | Valid for footer only. Never use as a content heading. | "Book Your AC Rental: Call 9018181818" |
| Get In Touch | Same as above | "Call 9018181818 or WhatsApp 8700359955" |
| Testimonials | Generic label | "What Renters in Delhi Say About KeyVendors" |

## Category 2: Em Dash and Colon Violations

Headings must not contain em dashes (---), en dashes (--), or colons. These create visual clutter and often signal AI-generated structure.

| Kill Pattern | Why | Fix |
|---|---|---|
| "AC on Rent --- Affordable Cooling for Delhi" | Em dash in heading | "AC on Rent in Delhi Starting Rs.999 Per Month" |
| "KeyVendors -- Your Trusted AC Rental Partner" | En dash in heading | "KeyVendors AC Rental: 1,200+ Customers Since 2016" then remove the colon too: "KeyVendors AC Rental Trusted by 1,200+ Customers Since 2016" |
| "AC Rental: What You Need to Know" | Colon creates a generic subhead pattern | "How AC Rental Works in Delhi (4 Simple Steps)" |
| "Split AC vs Window AC: Which Is Better?" | Colon acceptable ONLY in direct comparison H2s where it mirrors search intent | Keep ONLY if the target keyword is literally "Split AC vs Window AC" |

**Rule:** If a heading uses a colon, it passes only if the exact phrase (including colon) matches a high-volume search query. Otherwise, rewrite without the colon.

## Category 3: Question Filler Headings

Questions are valid only when they match real search queries with measurable volume. Rhetorical or marketing questions waste heading space.

| Kill | Why | Example Replacement |
|---|---|---|
| "Are You Looking for AC on Rent?" | The reader is already on the page, they answered this by clicking | "AC on Rent in Delhi Starting Rs.999 Per Month" |
| "Why Should You Rent an AC?" | Patronising, the reader already wants to rent | "Renting vs Buying: Save Rs.15,000+ Per Summer" |
| "What Makes KeyVendors Different?" | Generic trust question | "50+ Vetted Technicians and Free Installation Across Delhi NCR" |
| "Ready to Beat the Heat?" | Marketing fluff, not a search query | "Book a Window AC for Rs.999/Month" |
| "Need an AC for the Summer?" | Same as above | "AC on Rent in Delhi for 1 Month, 3 Months, or Full Season" |
| "Looking for Affordable AC Rental?" | Same as above | "AC Rental Plans in Delhi Starting Rs.999 Per Month" |
| "Want to Know More?" | Filler, never a heading | Delete the heading, fold content into the section above |

**Rule:** A question heading is acceptable ONLY if the exact question (or a close variant) appears in GSC query data or keyword research with volume above 10.

## Category 4: Good Heading Examples

These headings pass all tests. Use them as models for replacements.

| Heading | Why It Works |
|---|---|
| "AC on Rent in Delhi Starting Rs.999 Per Month" | Primary keyword + price + location |
| "Window AC vs Split AC: Which One Fits Your Room" | Comparison keyword + practical framing (passes only because "window ac vs split ac" is a real search query) |
| "1.5-Ton Split AC on Rent in Delhi for Rs.2,399/Month" | Long-tail keyword + price + location |
| "AC Rental Plans for Students and Tenants in Delhi" | Audience segment + keyword + location |
| "How AC Rental Works: Book, Install, Cool, Return" | Process keyword + 4-word summary of steps |
| "AC on Rent in Dwarka, Rohini, and South Delhi" | Locality-level keywords for local SEO |
| "Window AC Rental Price in Delhi: Rs.999 to Rs.1,499 Per Month" | Price-range keyword with specific numbers |
| "Free Installation and Maintenance with Every AC Rental" | Value proposition as heading, keyword present |
| "What Does AC on Rent in Delhi Cost Per Month?" | Exact match FAQ query with volume |
| "Rent a Split AC in Delhi Without Security Deposit" | Addresses a real objection with keyword |

---

## How to Use This List

1. Check every H1, H2, and H3 against the kill patterns above.
2. For exact matches, flag immediately and provide a replacement from Category 4 or write a new one following the same pattern.
3. For partial matches (e.g., "Our AC Rental Services" matches the pattern of "Our Services"), flag and rewrite.
4. Every replacement heading must contain at least ONE of: target keyword, specific price, Delhi NCR locality, or concrete data point.
5. A draft with more than zero Category 1 headings remaining scores 2 or below on Heading Quality.
