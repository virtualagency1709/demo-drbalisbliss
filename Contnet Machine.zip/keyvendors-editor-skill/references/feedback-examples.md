# Feedback Examples

## Purpose

Every piece of editor feedback must follow the three-part format:

1. **What is wrong** - Quote the exact text with line number
2. **Why it is wrong** - Name the specific rule it violates
3. **How to fix it** - Provide a complete rewrite the writer can copy-paste

Never give vague feedback like "make this more specific" or "improve the tone." The writer should be able to execute every fix in one pass without guessing what you meant.

---

## Example 1: Generic Heading

**What is wrong:**
> Line 14: `## Why Choose Us for AC Rental`

**Why it is wrong:**
Fails the heading kill list (Category 1: generic heading). "Why Choose Us" could appear on any competitor page. The heading contains no price, no locality, no specific proof point. Violates Phase 1 rule: every H2 must contain a target keyword and pass the "any AC rental company" test.

**How to fix it:**
```
## Why 1,200+ Delhi Customers Rent AC from KeyVendors
```
This version includes: social proof (1,200+), location (Delhi), brand name, and the target keyword (rent AC). A reader scanning the page gets a reason to read this section.

---

## Example 2: Banned Phrase in Body Copy

**What is wrong:**
> Line 42: "KeyVendors offers a comprehensive range of premium air conditioning units for rent across Delhi NCR."

**Why it is wrong:**
Three violations in one sentence:
- "comprehensive" (Tier 2 banned word: vague filler, says nothing about what is actually included)
- "premium" (Tier 1 banned word: wrong brand positioning, KeyVendors is budget-to-mid)
- "range of...units" (vague, does not name the actual AC types or prices)

**How to fix it:**
```
KeyVendors rents Window ACs (from Rs.999/month) and Split ACs (from Rs.2,399/month) across Delhi NCR. Both come with free installation and maintenance.
```
This version names the two AC types, gives starting prices for each, includes the location, and adds a concrete benefit. Zero banned words.

---

## Example 3: AI Pattern Opening

**What is wrong:**
> Line 1: "At KeyVendors, we believe that everyone deserves a cool and comfortable home during the harsh Delhi summers."

**Why it is wrong:**
Violates Tier 3 banned pattern: "At KeyVendors, we believe..." This is a brand-centric opening. The reader does not care what the company believes. They want to know the price, the AC options, and how fast they can get one installed. This sentence contains zero actionable information.

**How to fix it:**
```
Rent a Window AC in Delhi for Rs.999/month or a Split AC for Rs.2,399/month. KeyVendors delivers, installs, and maintains the unit. You just switch it on.
```
This version leads with the offer (price + product), follows with the value (delivery + installation + maintenance), and ends with a benefit (zero hassle). Three sentences, three facts.

---

## Example 4: Failing the "Any AC Rental Company" Test

**What is wrong:**
> Lines 28-31: "We provide top-quality air conditioners on rent with doorstep delivery and professional installation. Our team of trained technicians ensures that your AC is set up and running in no time. We also offer flexible rental plans to suit your needs."

**Why it is wrong:**
Fails Phase 3 substance check. Replace "We" with "Rentomojo" or "CityFurnish" and every sentence still works. No KeyVendors-specific data: no prices, no AC brands, no localities, no customer count, no timeline specifics. "Top-quality" is a banned vague adjective. "In no time" is filler (how long is installation actually?). "Flexible rental plans" names no plan.

**How to fix it:**
```
KeyVendors delivers and installs your AC within 48 hours of booking. Choose a 1-month, 3-month, or full-season plan. Window ACs (Voltas, Lloyd) start at Rs.999/month. Split ACs (Blue Star, Daikin) start at Rs.2,399/month. Our 50+ technicians cover all of Delhi NCR, including Dwarka, Rohini, Lajpat Nagar, and Noida.
```
Five sentences, five facts: timeline (48 hours), plan options (1/3/full season), Window AC price with brands, Split AC price with brands, coverage with localities.

---

## Example 5: Wrong Price Format

**What is wrong:**
> Line 55: "Window AC available at INR 999 per month."

**Why it is wrong:**
Violates Phase 6 price format rule. KeyVendors content uses "Rs." prefix, not "INR". The correct format is Rs.999/month (or Rs.X,XXX for thousands). "INR" reads like a banking document, not a service page for Delhi tenants.

**How to fix it:**
```
Window AC available at Rs.999/month.
```

---

## Example 6: Brand Name Misspelling

**What is wrong:**
> Line 8: "Keyvendors has been providing AC rental services since 2016."
> Line 23: "Key Vendors delivers across Delhi NCR."

**Why it is wrong:**
Two different misspellings of the brand name. The correct form is "KeyVendors" (capital K, capital V, one word). "Keyvendors" (lowercase v) and "Key Vendors" (two words) are both wrong. Brand name inconsistency hurts trust and looks unprofessional. Violates Phase 6 brand consistency rule.

**How to fix it:**
```
Line 8: "KeyVendors has been providing AC rental services since 2016."
Line 23: "KeyVendors delivers across Delhi NCR."
```
Search the entire document for "keyvendor", "Keyvendor", "key vendor", "Key Vendor", "KEYVENDOR" and correct every instance.

---

## Example 7: Missing CTA After Pricing Section

**What is wrong:**
> Lines 60-72: The pricing table section lists Window AC and Split AC monthly rates but ends with no call to action. The next section jumps to FAQs.

**Why it is wrong:**
Violates Phase 5 conversion rule: every section with a pricing mention must have a CTA within 200 words. The reader just saw prices and is primed to act. Without a CTA, they scroll past the decision moment. This is the highest-intent section on the page.

**How to fix it:**
Add a CTA block immediately after the pricing table:
```
Book your AC rental now. Call 9018181818 or WhatsApp 8700359955 for same-day booking.
```
Or for a softer intent stage:
```
Not sure which AC fits your room? Call 9018181818 and our team will recommend the right tonnage for your space.
```

---

## Example 8: Em Dash in Body Copy

**What is wrong:**
> Line 37: "Our AC rental service --- covering all of Delhi NCR --- includes free delivery and installation."

**Why it is wrong:**
Em dashes are banned in all KeyVendors content (Tier 4 punctuation ban). They create visual clutter and are a common AI writing pattern. Replace with commas, periods, or parentheses.

**How to fix it:**
```
Our AC rental service covers all of Delhi NCR and includes free delivery and installation.
```
Simpler, cleaner, says the same thing. The parenthetical aside added nothing that a conjunction cannot handle.

---

## Example 9: Vague FAQ Answer

**What is wrong:**
> Line 88: "Q: What is the price of AC on rent in Delhi?"
> Line 89: "A: At KeyVendors, we offer affordable and flexible pricing plans for AC rental in Delhi. Our prices are competitive and designed to fit every budget."

**Why it is wrong:**
The answer contains zero actual prices. It uses two banned patterns ("At KeyVendors, we offer" and "affordable"). The question is a high-volume keyword query (Rs.390 monthly search volume for "ac on rent in delhi price") and the answer fails to give the one thing the searcher wants: a number. This also fails AEO (Answer Engine Optimisation) because an LLM extracting this answer gets no data to cite.

**How to fix it:**
```
Q: What is the price of AC on rent in Delhi?
A: Window AC rental in Delhi starts at Rs.999/month. Split AC rental starts at Rs.2,399/month. Both plans include free delivery, installation, and maintenance. Seasonal plans (3+ months) get lower per-month rates. Call 9018181818 for exact pricing based on your AC type and rental duration.
```
The first sentence directly answers the question with a number. The second gives the other option. The third adds value. The fourth creates urgency. The fifth provides a CTA.

---

## Example 10: Passive Voice

**What is wrong:**
> Line 45: "The AC will be delivered and installed by our trained technicians within 48 hours."

**Why it is wrong:**
Passive voice ("will be delivered and installed by"). KeyVendors content uses active voice and present tense. Passive voice distances the brand from the action and sounds corporate.

**How to fix it:**
```
Our technicians deliver and install your AC within 48 hours of booking.
```
Active voice, present tense, same information. The subject (technicians) performs the action (deliver and install) directly.

---

## Checklist Before Submitting Feedback

For every finding in your review, verify:

- [ ] You quoted the exact text from the draft
- [ ] You included the line number (or section name if line numbers are unavailable)
- [ ] You named the specific rule being violated (phase number, banned word tier, kill list category)
- [ ] Your rewrite is complete and copy-pasteable (not "something like..." or "consider...")
- [ ] Your rewrite itself passes all rules (no banned words, correct price format, correct brand name)
- [ ] You did not introduce new problems in your rewrite (check it against the banned list too)
