# Banned Phrases and Patterns

## Purpose

These words and patterns must never appear in any KeyVendors AC rental content. They signal AI-generated copy, luxury positioning (wrong for our brand), or vague filler that adds no value. Every occurrence must be flagged with a specific replacement.

---

## Tier 1: Luxury and Premium Vocabulary (Wrong Brand Positioning)

These words position the brand as luxury or aspirational. KeyVendors is budget-to-mid, practical, and proof-driven. Using these words misleads the reader about what to expect.

| Banned Word | Why | Replace With |
|---|---|---|
| luxury | Wrong positioning, we are budget-friendly | "quality" or "reliable" |
| premium | Implies high-end pricing | "well-maintained" or specify the brand (Voltas, Blue Star) |
| bespoke | Nobody searching for AC on rent uses this word | "custom" or "based on your room size" |
| world-class | Unsubstantiated superlative | "rated 4.8/5 by 1,200+ customers" |
| best-in-class | Same as above | a specific stat or feature |
| pinnacle | Pure filler | delete entirely |
| elegance | Luxury vocabulary, wrong audience | "clean", "modern" |
| sophistication | Same as above | delete or replace with specific feature |
| opulence | Absurd for AC rental content | delete entirely |
| artisan | Nobody describes AC technicians this way | "experienced technician" or "trained professional" |
| craftsmanship | Same as above | "build quality" or name the AC brand |
| state-of-the-art | Vague and overused | name the specific feature or model |
| cutting-edge | Same as above | name the specific technology (e.g., "inverter compressor") |
| unparalleled | Unsubstantiated | use a specific comparison or stat |

## Tier 2: AI Filler Words (GPT/Claude Tells)

These words appear disproportionately in AI-generated content. Human writers rarely use them. Their presence signals the content was not properly edited.

| Banned Word | Why | Replace With |
|---|---|---|
| plethora | AI tell, overly formal | "many" or a specific number |
| myriad | Same as above | "several" or a specific number |
| seamless | Vague, says nothing | describe what specifically works smoothly (e.g., "we deliver and install in one visit") |
| holistic | Buzzword, no meaning in AC rental context | describe the specific scope (e.g., "delivery, installation, and maintenance included") |
| comprehensive | Vague filler | list what is actually included |
| delve | AI tell | "look at", "cover", "explain" |
| leverage | Corporate jargon | "use" |
| utilize | Same as above | "use" |
| facilitate | Same as above | "help", "handle", "manage" |
| optimal | Vague | "best" or specify the actual outcome |
| robust | Meaningless in consumer context | describe the specific feature |
| empower | Aspirational corporate speak | delete or rephrase with concrete action |
| elevate | Same as above | delete or use "improve" with specifics |
| endeavour | Overly formal | "work", "effort" |
| foster | AI tell | "build", "create" |
| harness | AI tell | "use" |
| navigate | Overused metaphor | "handle", "manage", "deal with" |
| paramount | Overly dramatic | "important" or "critical" |
| pivotal | Same as above | "key", "important" |
| realm | AI tell | "area", "field", or delete |
| bolster | AI tell | "strengthen", "support" |
| landscape | Used metaphorically, vague | "market", "options available" |
| spearhead | AI tell | "lead", "start" |

## Tier 3: Banned Sentence Patterns

These patterns are structural tells of AI-generated content. Flag every occurrence.

| Pattern | Why It Fails | How to Fix |
|---|---|---|
| "At KeyVendors, we believe..." | Brand-centric opening, nobody cares what you believe | Start with the fact or benefit: "Window AC rental starts at Rs.999/month." |
| "We understand that..." | Patronising, wastes the reader's time | State the problem directly: "Delhi summers hit 45 degrees by May." |
| "Whether you're looking for X or Y, we've got you covered" | Vague catch-all, no specifics | "Window AC for a small room: Rs.999/month. Split AC for a larger space: Rs.2,399/month." |
| "In today's fast-paced world..." | Throat-clearing filler | Delete the entire sentence. Start with the point. |
| "In the scorching Delhi summers..." | Cliche opening for AC content | Start with the offer or the problem. "Your room temperature hits 38 degrees without an AC." |
| "Look no further" | Dated marketing speak | Delete. Let the content prove the claim. |
| "One-stop solution" | Vague, says nothing specific | List what is included: "delivery, installation, maintenance, and pickup" |
| "Are you looking for..." | Question filler, wastes H2/H3 space | Rewrite as a statement with the keyword |
| "It goes without saying..." | Then do not say it | Delete the phrase, keep the content |
| "It is worth noting that..." | Filler | Delete the phrase, keep the content |
| "When it comes to..." | Weak transition | Start with the subject directly |
| "Rest assured" | Patronising | State the specific guarantee instead |
| "With that being said" | Transition filler | Delete or use "That said," if transition is genuinely needed |

## Tier 4: Punctuation and Formatting Bans

| Pattern | Rule |
|---|---|
| Em dash (---) | Never use. Replace with comma, period, or parentheses. |
| En dash (--) in prose | Use only in number ranges (Rs.999--2,399). Never in sentences. |
| Exclamation marks in body copy | Maximum 1 per page, in a CTA only. Never in headings or descriptions. |
| ALL CAPS for emphasis | Never. Use bold if emphasis is needed. |
| Ellipsis (...) | Never in headings. Maximum 1 in body copy if genuinely needed. |

---

## How to Use This List

1. Before submitting any review, do a full-text search for every Tier 1 and Tier 2 word.
2. For each match, record: the exact sentence, the line number, and a rewritten version.
3. For Tier 3 patterns, search for the opening phrase and flag the full sentence.
4. For Tier 4, search for the punctuation marks and correct each one.
5. A draft with any Tier 1 word remaining is an automatic fail on the Voice and Tone dimension.
